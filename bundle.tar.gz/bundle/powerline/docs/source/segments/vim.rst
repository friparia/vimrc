************
Vim segments
************

.. automodule:: powerline.segments.vim
   :members:
